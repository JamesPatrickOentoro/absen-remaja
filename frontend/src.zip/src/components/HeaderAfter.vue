<template>
    <nav class="navbar bg-body-tertiary" id="header-nav">
        <div class="container-fluid">
            <a class="navbar-brand">Dashboard</a>
        </div>
    </nav>
</template>


<script>
export default {
    name: 'HeaderAfter',
}
</script>

<style></style>